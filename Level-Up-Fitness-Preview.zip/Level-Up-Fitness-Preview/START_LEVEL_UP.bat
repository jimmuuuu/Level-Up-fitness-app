@echo off
cd /d "%~dp0"
echo Starting Level Up Fitness at http://127.0.0.1:4173/
echo Keep this window open while using the app.
start "" http://127.0.0.1:4173/
where py >nul 2>nul
if %errorlevel%==0 (
  py -m http.server 4173 --bind 127.0.0.1
) else (
  python -m http.server 4173 --bind 127.0.0.1
)
pause
